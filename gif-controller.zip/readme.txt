=== Gif Controller ===
Contributors: Mostafa Shahiri
Tags: Post, gif image, automatic, posts, featured image, image, gif, images
Requires at least: 3.6.1
Tested up to: 4.4.x
Stable tag: 3.4.0

The GIF Controller is a simple and lightweight plugin for playing and stopping the GIF images.

== Description ==

The GIF Controller is a simple and lightweight plugin for playing and stopping the GIF images. It finds gif images from the content of posts and generate a similar jpeg image
automatically at the same path with the same name. In the admin page of this plugin, you can determine some settings such as playing the gif images on mouse hover, wait to load and
the text label for the play button of the gif images.

== Installation ==

Upload the Gif Controller plugin to your blog, Activate it.

== Changelog ==

= 1.0 =
First release
